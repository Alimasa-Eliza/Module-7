 <?php

$Firstname=$_POST['Firstname'];
$Middlename=$_POST['Middlename'];
$Lastname=$_POST['Lastname'];
$Subjects=$_POST['Subjects'];
$Email=$_POST['Email'];
$Sex=$_POST['Sex'];
$error = '';

if (!filter_var($Email, FILTER_VALIDATE_EMAIL)) {
  $error .= 'Invalid email address. Please provide the correct information required.';
}

if (!empty($error)) {
  echo 'Validation Error: ' . $error;
  exit();
}

        echo 'Firstname: ' .$Firstname .'<br/>';
        echo 'Middlename: ' .$Middlename .'<br/>';
        echo 'Lastname: ' .$Lastname .'<br/>';
        echo 'Sex: ' .$Sex .'<br/>';
        echo 'Email: ' .$Email .'<br/>';
        echo 'Subjects Taken: ' .'<br/>';

        foreach ($Subjects as $subject) {
          echo $subject . '<br/>';
      }

      echo'<hr>';
      
      $csvFileName = 'user_data.csv';
      $csvFile = fopen($csvFileName, 'a');
      
      if ($csvFile) {
          $userData = array($Firstname, $Middlename, $Lastname, $Email, $Sex, implode(', ', $Subjects));
      
          // Display user info in CSV format
          echo 'User\'s information in CSV format: ' . implode(',', $userData) . '<br/>';
      
          // Write user information to CSV file
          fputcsv($csvFile, $userData);
          fclose($csvFile);
      } else {
    echo 'Error creating/opening the CSV file.';
}
      echo'<hr>';

      echo 'Table of User\'s Information:'.'<br/>';
echo '<table border="5">';
echo '<tr><td>Firstname </td>
          <td>   Middlename </td>
          <td>  Lastname </td>
          <td>   Email </td>
          <td>  Sex </td>
          <td>  Subjects Taken</td>
      </tr>';

$csvFile = fopen($csvFileName, 'r');

if ($csvFile) {
    while (($userData = fgetcsv($csvFile)) !== false) {
        echo '<tr>';
        foreach ($userData as $data) {
            echo '<td>' . $data . '</td>';
        }
        echo '</tr>';
    }
    fclose($csvFile);
} else {
    echo 'CSV file opening error has occurred.';
}

echo '</table>';
echo '<hr>';

?>

